class CreateTurmaHasCandidatos < ActiveRecord::Migration
  def change
    create_table :turma_has_candidatos do |t|
    end
  end
end
